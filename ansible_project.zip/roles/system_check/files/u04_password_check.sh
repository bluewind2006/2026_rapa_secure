#!/bin/bash
# ============================================================
# [U-04] 패스워드 파일 보호 점검 스크립트
# ============================================================

RESULT_FILE="/var/log/system_check/U04_result_$(date +%Y%m%d_%H%M%S).log"

VULN_POS=0
RESULT="N/A"
IS_VULNERABLE=false

echo "[U-04] 패스워드 파일 보호" | tee -a "$RESULT_FILE"
echo "[점검목적]" | tee -a "$RESULT_FILE"
echo "passwd 파일에 평문 또는 비어있는 암호가 있는지 확인" | tee -a "$RESULT_FILE"
echo "" | tee -a "$RESULT_FILE"

########################################
# 1. /etc/shadow 파일 존재 여부
########################################
echo "1. shadow 파일 존재 여부 확인" | tee -a "$RESULT_FILE"

if [[ ! -f /etc/shadow ]]; then
    echo "- /etc/shadow 파일이 존재하지 않습니다." | tee -a "$RESULT_FILE"
    RESULT="취약"
else
    echo "\$ ls -l /etc/shadow" | tee -a "$RESULT_FILE"
    ls -l /etc/shadow | tee -a "$RESULT_FILE"

    ########################################
    # 2. /etc/passwd 두 번째 필드 확인
    ########################################
    echo "" | tee -a "$RESULT_FILE"
    echo "2. passwd 파일 내 패스워드 필드(x 여부) 확인" | tee -a "$RESULT_FILE"
    echo "\$ awk -F: '\$2 != \"x\" {print}' /etc/passwd" | tee -a "$RESULT_FILE"

    WEAK_ACCOUNTS=$(awk -F: '$2 != "x" {print}' /etc/passwd)

    if [[ -n "$WEAK_ACCOUNTS" ]]; then
        IS_VULNERABLE=true
        echo "취약한 계정 발견:" | tee -a "$RESULT_FILE"
        echo "$WEAK_ACCOUNTS" | tee -a "$RESULT_FILE"
    else
        echo "모든 계정이 shadow 비밀번호를 사용 중입니다." | tee -a "$RESULT_FILE"
    fi


# 3. /etc/shadow 빈 패스워드 계정 확인  ### [추가]
    ########################################
    echo "" | tee -a "$RESULT_FILE"
    echo "3. shadow 파일 내 빈 패스워드 계정 확인" | tee -a "$RESULT_FILE"
    echo "\$ awk -F: '\$2 == \"\" {print}' /etc/shadow" | tee -a "$RESULT_FILE"

    EMPTY_SHADOW_ACCOUNTS=$(awk -F: '$2 == "" {print $1}' /etc/shadow)

    if [[ -n "$EMPTY_SHADOW_ACCOUNTS" ]]; then
        IS_VULNERABLE=true
        echo "빈 패스워드 계정 발견:" | tee -a "$RESULT_FILE"
        echo "$EMPTY_SHADOW_ACCOUNTS" | tee -a "$RESULT_FILE"
    else
        echo "빈 패스워드 계정이 존재하지 않습니다." | tee -a "$RESULT_FILE"
    fi

    ########################################
    # 진단 결과 판단
    ########################################
    echo "" | tee -a "$RESULT_FILE"
    echo "[진단결과]" | tee -a "$RESULT_FILE"

    if [[ "$IS_VULNERABLE" == true ]]; then
        RESULT="취약"
         echo "- 진단근거: passwd 파일에 x가 아닌 패스워드 필드 또는 shadow 파일에 빈 패스워드 계정이 존재합니다." | tee -a "$RESULT_FILE"
    else
        RESULT="양호"
        echo "- 진단근거: shadow 파일이 존재하며 passwd 파일에 비어있는 패스워드가 없습니다." | tee -a "$RESULT_FILE"
    fi
fi

########################################
# 최종 결과 출력
########################################
echo "" | tee -a "$RESULT_FILE"
echo "[최종점검결과] $RESULT" | tee -a "$RESULT_FILE"
echo "취약항목 위치: $VULN_POS" | tee -a "$RESULT_FILE"

echo "" | tee -a "$RESULT_FILE"
echo "============================================================================" | tee -a "$RESULT_FILE"
echo "계정 관리 점검 완료" | tee -a "$RESULT_FILE"
echo "============================================================================" | tee -a "$RESULT_FILE"
